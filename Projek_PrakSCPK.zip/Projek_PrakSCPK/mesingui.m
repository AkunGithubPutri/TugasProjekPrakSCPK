function varargout = mesingui(varargin)
% MESINGUI MATLAB code for mesingui.fig
%      MESINGUI, by itself, creates a new MESINGUI or raises the existing
%      singleton*.
%
%      H = MESINGUI returns the handle to a new MESINGUI or the handle to
%      the existing singleton*.
%
%      MESINGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MESINGUI.M with the given input arguments.
%
%      MESINGUI('Property','Value',...) creates a new MESINGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before mesingui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to mesingui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help mesingui

% Last Modified by GUIDE v2.5 01-Jun-2020 10:31:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @mesingui_OpeningFcn, ...
                   'gui_OutputFcn',  @mesingui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before mesingui is made visible.
function mesingui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to mesingui (see VARARGIN)

% Choose default command line output for mesingui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
movegui(hObject, 'center');
% UIWAIT makes mesingui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = mesingui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)      %menggil slide 2 melakukan input(suhu)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slider_suhu = get(hObject,'Value');
set(handles.edit2, 'string', strcat(num2str(slider_suhu),' *C'));
 
%membuat batasan parameter suhu
if slider_suhu <= 10
    suhu = 'dingin';
elseif slider_suhu > 10 && slider_suhu <= 20
    suhu = 'sejuk';
elseif slider_suhu > 20 && slider_suhu <= 27
    suhu = 'normal';
elseif slider_suhu > 27 && slider_suhu <= 35
    suhu = 'hangat';
else
    suhu = 'panas';
end
 
set(handles.text14, 'string', suhu);

 %membaca nilai variabel
slider_cahaya = get(handles.slider3,'Value');
slider_usiapakaimesin = get(handles.slider6,'Value');
slider_waktu = get(handles.slider5,'Value');

input = [slider_suhu slider_cahaya slider_waktu slider_usiapakaimesin];
fis = readfis('mesin');
out = evalfis(input,fis);
 
%keluaran kec.mesin setelah input suhu
if out <= 10
    kec_mesin = 'lambat';
elseif out > 10 && out <= 18
    kec_mesin = 'sedang';
else
    kec_mesin = 'cepat';
end
 
set(handles.edit4,'string',strcat(num2str(out),' m/s'));
set(handles.text24, 'string', kec_mesin);

% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)      %memnggil slide 3 melakukan input (cahaya)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slider_cahaya = get(hObject,'Value');
set(handles.edit3, 'string', strcat(num2str(slider_cahaya),' Cd'));
 
%membuat btasan range var cahaya
if slider_cahaya <= 30
    cahaya = 'gelap';
elseif slider_cahaya > 30 && slider_cahaya <= 80
    cahaya = 'normal';
else
    cahaya = 'terang';
end
 
set(handles.text15, 'string', cahaya);

 %membaca nilai variabel
slider_suhu = get(handles.slider2,'Value');
slider_usiapakaimesin = get(handles.slider6,'Value');
slider_waktu = get(handles.slider5,'Value');

input = [slider_suhu slider_cahaya slider_waktu slider_usiapakaimesin];
fis = readfis('mesin');
out = evalfis(input,fis);
 %keluaran kec.mesin setelah input cahaya
if out <= 10
    kec_mesin = 'lambat';
elseif out > 10 && out <= 18
    kec_mesin = 'sedang';
else
    kec_mesin = 'cepat';
end
 
set(handles.edit4,'string',strcat(num2str(out),' m/s'));
set(handles.text24, 'string', kec_mesin);

% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


%memanggil edit 2 hasil inputan(suhu)
function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%memanggil edit3 melakukan input(cahaya)
function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)    %memanggil edit 4 hasil inputan(waktu)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider5_Callback(hObject, eventdata, handles)  %%memenggil slider5 melakukan input (waktu)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slider_waktu = get(hObject,'Value');
set(handles.edit5, 'string', strcat(num2str(slider_waktu),' Jam')); %membuat edit 5 hasil waktu mengunakan string jam
 
%membuat batasan rage var waktu
if slider_waktu <= 7
    waktu = 'cepat';
elseif slider_waktu > 7 && slider_waktu <= 14
    waktu = 'sedang';
else
    waktu = 'lambat';
end
 
set(handles.text23, 'string', waktu);
 
%membaca hasil nilai inputan pada var waktu,suhu,cahaya
slider_usiapakaimesin = get(handles.slider6,'Value');
slider_suhu = get(handles.slider2,'Value');
slider_cahaya = get(handles.slider3,'Value');

input = [slider_suhu slider_cahaya slider_waktu slider_usiapakaimesin];
fis = readfis('mesin');
out = evalfis(input,fis);
 
%keluaran kec.mesin setelah input waktu
if out <= 10
    kec_mesin = 'lambat';
elseif out > 10 && out <= 18
    kec_mesin = 'sedang';
else
    kec_mesin = 'cepat';
end
 
set(handles.edit4,'string',strcat(num2str(out),' m/s'));
set(handles.text24, 'string', kec_mesin);

% --- Executes during object creation, after setting all properties.
function slider5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider6_Callback(hObject, eventdata, handles)      %memnggil slide6 melakukan input(var.usia pakai)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slider_usiapakaimesin = get(hObject,'Value');
set(handles.edit6, 'string', strcat(num2str(slider_usiapakaimesin),' Tahun')); %membuat edit 6 dengan memakai string tahun
 
%membuat batasan range variabel usia pakai mesin
if slider_usiapakaimesin <= 3
    usiapakaimesin = 'baru';
elseif slider_usiapakaimesin > 3 && slider_usiapakaimesin <= 6
    usiapakaimesin = 'sedang';
else
    usiapakaimesin = 'lama';
end
 
set(handles.text25, 'string', usiapakaimesin); %
 
%membaca hasil nilai inputan pada var waktu,suhu,cahaya
slider_waktu = get(handles.slider5,'Value');
slider_suhu = get(handles.slider2,'Value');
slider_cahaya = get(handles.slider3,'Value');

input = [slider_suhu slider_cahaya slider_waktu slider_usiapakaimesin];
fis = readfis('mesin');
out = evalfis(input,fis);

 %keluaran kec.mesin setelah input usia pakai
if out <= 10
    kec_mesin = 'lambat';
elseif out > 10 && out <= 18
    kec_mesin = 'sedang';
else
    kec_mesin = 'cepat';
end
 
set(handles.edit4,'string',strcat(num2str(out),' m/s'));
set(handles.text24, 'string', kec_mesin);

% --- Executes during object creation, after setting all properties.
function slider6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


%........memanggil edit5 hasil inputan (kecepatan mesin)Hasil akhir........
function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)  
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%
function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
